
using Microsoft.Data.SqlClient;
using System.Data;
using System.Data.SqlClient;
namespace AppDev
{
    public partial class flogin : Form
    {
        string conn = ("Data Source=LAPTOP-C7B1RTSD\\SQLEXPRESS;Initial Catalog=AppDev;Integrated Security=True;Trust Server Certificate=True");
        public flogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtuname.Text == "" && txtpass.Text == "")
            {
                MessageBox.Show("Please fill in the blanks!");
            }
            else
            {
                SqlConnection con = new SqlConnection(conn);
                SqlCommand cmd = new SqlCommand("select * from Secure where IDNumber=@UIDNumber and Passpot=@UPasspot", con);
                cmd.Parameters.AddWithValue("@UIDNumber", txtuname.Text);
                cmd.Parameters.AddWithValue("@UPasspot", txtpass.Text);

                con.Open();
                SqlDataAdapter adpt = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adpt.Fill(ds);
                con.Close();

                int count = ds.Tables[0].Rows.Count;
                if (count == 1)
                {
                    Successfully scs = new Successfully();
                    scs.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Please check IDNumber Or DateIssued!");
                }
            }
        }

        private void txtuname_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void lblcancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            NewUser nwu = new NewUser();
            nwu.Show();
            this.Hide();
        }
    }
}
