﻿namespace AppDev
{
    partial class flogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(flogin));
            txtuname = new TextBox();
            txtpass = new TextBox();
            btnLogin = new Button();
            comboBox1 = new ComboBox();
            label1 = new Label();
            lblcancel = new Label();
            label3 = new Label();
            label4 = new Label();
            linkLabel1 = new LinkLabel();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtuname
            // 
            txtuname.BackColor = SystemColors.Window;
            txtuname.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtuname.ForeColor = Color.Black;
            txtuname.Location = new Point(444, 411);
            txtuname.Multiline = true;
            txtuname.Name = "txtuname";
            txtuname.PlaceholderText = "ID";
            txtuname.Size = new Size(588, 44);
            txtuname.TabIndex = 2;
            txtuname.Validating += txtuname_Validating;
            // 
            // txtpass
            // 
            txtpass.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtpass.Location = new Point(444, 510);
            txtpass.Multiline = true;
            txtpass.Name = "txtpass";
            txtpass.PasswordChar = '*';
            txtpass.PlaceholderText = "Date issued";
            txtpass.Size = new Size(588, 42);
            txtpass.TabIndex = 3;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(0, 64, 0);
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.FlatAppearance.MouseOverBackColor = Color.Red;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(444, 603);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(588, 43);
            btnLogin.TabIndex = 4;
            btnLogin.Text = "Proceed";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.ForeColor = SystemColors.ControlDarkDark;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "ID Number", "Passpot Number" });
            comboBox1.Location = new Point(444, 355);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(588, 33);
            comboBox1.TabIndex = 5;
            comboBox1.Text = "[SELECT]";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(444, 475);
            label1.Name = "label1";
            label1.Size = new Size(336, 23);
            label1.TabIndex = 6;
            label1.Text = "*ID Or Passpot Issued Date. as Password!";
            // 
            // lblcancel
            // 
            lblcancel.AutoSize = true;
            lblcancel.BackColor = Color.Red;
            lblcancel.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblcancel.ForeColor = Color.White;
            lblcancel.Location = new Point(1470, 9);
            lblcancel.Name = "lblcancel";
            lblcancel.Size = new Size(24, 25);
            lblcancel.TabIndex = 8;
            lblcancel.Text = "X";
            lblcancel.Click += lblcancel_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.ControlDarkDark;
            label3.Location = new Point(639, 845);
            label3.Name = "label3";
            label3.Size = new Size(287, 20);
            label3.TabIndex = 9;
            label3.Text = "Secure Portal @ 2024 | We Care";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = SystemColors.ControlDarkDark;
            label4.Location = new Point(408, 267);
            label4.Name = "label4";
            label4.Size = new Size(668, 44);
            label4.TabIndex = 10;
            label4.Text = " Please note that this Portal is only available for individuals who \r\nhave a South African ID Number or a Passport registered on our system.";
            label4.TextAlign = ContentAlignment.TopCenter;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.LinkBehavior = LinkBehavior.HoverUnderline;
            linkLabel1.LinkColor = Color.Red;
            linkLabel1.Location = new Point(638, 687);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(142, 22);
            linkLabel1.TabIndex = 13;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Register Here!";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.Gray;
            label5.Location = new Point(450, 687);
            label5.Name = "label5";
            label5.Size = new Size(183, 22);
            label5.TabIndex = 12;
            label5.Text = "Don't have Access?";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-1, 1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1508, 189);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // flogin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1506, 900);
            Controls.Add(lblcancel);
            Controls.Add(linkLabel1);
            Controls.Add(label5);
            Controls.Add(pictureBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(comboBox1);
            Controls.Add(btnLogin);
            Controls.Add(txtpass);
            Controls.Add(txtuname);
            FormBorderStyle = FormBorderStyle.None;
            MaximizeBox = false;
            Name = "flogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtuname;
        private TextBox txtpass;
        private Button btnLogin;
        private ComboBox comboBox1;
        private Label label1;
        private Label lblcancel;
        private Label label3;
        private Label label4;
        private LinkLabel linkLabel1;
        private Label label5;
        private PictureBox pictureBox1;
    }
}
