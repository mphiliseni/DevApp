﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev
{
    public partial class Appointmnt : Form
    {
        public Appointmnt()
        {
            InitializeComponent();
        }

        private void lblcancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            UStatus ustas = new UStatus();
            ustas.Show();
            this.Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            flogin flog = new flogin();
            flog.Show();
            this.Hide();
        }
    }
}
