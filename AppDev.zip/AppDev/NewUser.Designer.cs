﻿namespace AppDev
{
    partial class NewUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblcancel = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox3 = new TextBox();
            label6 = new Label();
            textBox2 = new TextBox();
            label5 = new Label();
            textBox1 = new TextBox();
            cb1 = new ComboBox();
            lblTitle = new Label();
            comboBox3 = new ComboBox();
            label10 = new Label();
            comboBox2 = new ComboBox();
            label9 = new Label();
            comboBox1 = new ComboBox();
            label8 = new Label();
            textBox4 = new TextBox();
            label7 = new Label();
            textBox6 = new TextBox();
            label13 = new Label();
            comboBox4 = new ComboBox();
            label12 = new Label();
            textBox5 = new TextBox();
            label11 = new Label();
            btnCancel = new Button();
            btnSub = new Button();
            SuspendLayout();
            // 
            // lblcancel
            // 
            lblcancel.AutoSize = true;
            lblcancel.BackColor = Color.Red;
            lblcancel.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblcancel.ForeColor = Color.White;
            lblcancel.Location = new Point(1470, 9);
            lblcancel.Name = "lblcancel";
            lblcancel.Size = new Size(24, 25);
            lblcancel.TabIndex = 10;
            lblcancel.Text = "X";
            lblcancel.Click += lblcancel_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.ForestGreen;
            label3.Location = new Point(110, 169);
            label3.Name = "label3";
            label3.Size = new Size(1049, 22);
            label3.TabIndex = 60;
            label3.Text = " Please capture your details as they appear on your Identity Document \\ Passport or Birth Certificate. ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Segoe UI", 28.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(110, 84);
            label2.Name = "label2";
            label2.Size = new Size(394, 62);
            label2.TabIndex = 64;
            label2.Text = "Enter Your Details";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(566, 222);
            label1.Name = "label1";
            label1.Size = new Size(99, 25);
            label1.TabIndex = 92;
            label1.Text = "Initial(s)";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(566, 359);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = " *Surname ";
            textBox3.Size = new Size(380, 41);
            textBox3.TabIndex = 91;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(566, 320);
            label6.Name = "label6";
            label6.Size = new Size(131, 25);
            label6.TabIndex = 90;
            label6.Text = " *Surname ";
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(129, 359);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.PlaceholderText = " *Full forename(s) ";
            textBox2.Size = new Size(364, 41);
            textBox2.TabIndex = 89;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(129, 320);
            label5.Name = "label5";
            label5.Size = new Size(207, 25);
            label5.TabIndex = 88;
            label5.Text = " *Full forename(s) ";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(566, 258);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = " *Initial(s) ";
            textBox1.Size = new Size(380, 42);
            textBox1.TabIndex = 87;
            // 
            // cb1
            // 
            cb1.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            cb1.FormattingEnabled = true;
            cb1.Items.AddRange(new object[] { "[Select]", "Mr", "Miss", "Mrs", "Dr", "Prof" });
            cb1.Location = new Point(129, 258);
            cb1.Name = "cb1";
            cb1.Size = new Size(364, 30);
            cb1.TabIndex = 86;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblTitle.Location = new Point(152, 222);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(64, 25);
            lblTitle.TabIndex = 85;
            lblTitle.Text = "Tittle";
            // 
            // comboBox3
            // 
            comboBox3.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox3.ForeColor = Color.Black;
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30" });
            comboBox3.Location = new Point(1046, 475);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(222, 30);
            comboBox3.TabIndex = 100;
            comboBox3.Text = "DAY";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(1046, 432);
            label10.Name = "label10";
            label10.Size = new Size(78, 25);
            label10.TabIndex = 99;
            label10.Text = "  *Day";
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox2.ForeColor = Color.Black;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "[MONTH]", "January", "February", "March April", "May", "June", "July", "August", "September", "October", "November", "December" });
            comboBox2.Location = new Point(790, 475);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(227, 30);
            comboBox2.TabIndex = 98;
            comboBox2.Text = "[MONTH]";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(790, 432);
            label9.Name = "label9";
            label9.Size = new Size(102, 25);
            label9.TabIndex = 97;
            label9.Text = "  *Month";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "[Year]", "2023", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012", "2011", "2010", "2009", "2008", "2007", "2006", "2005", "2004", "2003", "2002", "2001", "2000", "1999", "1998", "1997", "1996", "1995", "1994", "1993", "1992", "1991", "1990", "1989", "1988", "1987", "1986", "1985", "1984", "1983", "1982", "1981", "1980", "1979", "1978", "1977", "1976", "1975", "1974", "1973", "1972", "1971", "1970", "1969", "1968", "1967", "1966", "1965", "1964", "1963", "1962", "1961", "1960", "1959", "1958", "1957", "1956", "1955", "1954", "1953", "1952", "1951", "1950", "1949", "1948", "1947", "1946", "1945", "1944", "1943", "1942", "1941", "1940", "1939", "1938", "1937", "1936", "1935", "1934", "1933", "1932", "1931", "1930", "1929", "1928", "1927", "1926", "1925", "1924", "1923", "1922", "1921", "1920", "1919", "1918", "1917", "1916", "1915", "1914", "1913", "1912", "1911", "1910", "1909", "1908", "1907", "1906", "1905", "1904" });
            comboBox1.Location = new Point(566, 475);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(192, 30);
            comboBox1.TabIndex = 96;
            comboBox1.Text = "[Year]";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(566, 432);
            label8.Name = "label8";
            label8.Size = new Size(176, 25);
            label8.TabIndex = 95;
            label8.Text = "  *Date of Birth ";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.Location = new Point(130, 471);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.PlaceholderText = " *ID Number ";
            textBox4.Size = new Size(373, 33);
            textBox4.TabIndex = 94;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(120, 432);
            label7.Name = "label7";
            label7.Size = new Size(149, 25);
            label7.TabIndex = 93;
            label7.Text = " *ID Number ";
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.Location = new Point(790, 588);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.PlaceholderText = "   *Cellphone No ";
            textBox6.Size = new Size(227, 33);
            textBox6.TabIndex = 106;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(790, 553);
            label13.Name = "label13";
            label13.Size = new Size(187, 25);
            label13.TabIndex = 105;
            label13.Text = "   *Cellphone No ";
            // 
            // comboBox4
            // 
            comboBox4.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "Afghanistan (+93)", "Albania (+355)", "Algeria (+213)", "American Samoa (+685)", "Andorra (+376)", "Angola (+244)", "nguilla (+1)", "Antarctica (+672)", "ntigua and Barbuda (+1)", "Argentina (+54)", "Armenia (+374)", "Aruba (+297)", "Australia (+61)", "Austria (+43)", "Azerbaijan (+994)", "ahamas (+1)", "Bahrain (+973)", "Bangladesh (+880)", "arbados (+1)", "Belarus (+375)", "Belgium (+32)", "Belize (+501)", "Benin (+229)", "ermuda (+1)", "Bhutan (+975)", "Bolivia (+591)", "Bosnia and Herzegovina ", "Botswana (+267)", "Brazil (+55)</option", "ritish Virgin Islands (+1)", "Brunei (+673)", "Bulgaria (+359)", "Burkina Faso (+226)", "Burma (Myanmar) (+95)", "Burundi (+257)", "Cambodia (+855)", "Cameroon (+237)", "anada ", "Cape Verde (+238)", "ayman Islands (+1)", "Central African Republic (+242)", "Chad (+235)", "Chile (+56)", "China (+86)", "Christmas Island (+61)", "Cocos (Keeling) Islands (+61)", "Colombia (+57)", "Comoros (+269)", "Cook Islands (+682)", "Costa Rica (+506)", "Croatia (+385)", "Cuba (+53)", "Cyprus (+357)", "Czech Republic (+420)", "Democratic Republic of the ", "Denmark (+45)", "Djibouti (+253)", "ominica (+1)", "ominican Republic (+1)", "Nicaragua (+505)", "South Africa (+27)", "", "", "" });
            comboBox4.Location = new Point(567, 591);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(191, 30);
            comboBox4.TabIndex = 104;
            comboBox4.Text = "[Number]";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(555, 553);
            label12.Name = "label12";
            label12.Size = new Size(176, 25);
            label12.TabIndex = 103;
            label12.Text = "   *Choose Code";
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox5.Location = new Point(129, 591);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.PlaceholderText = " *Email Address";
            textBox5.Size = new Size(374, 33);
            textBox5.TabIndex = 102;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(129, 542);
            label11.Name = "label11";
            label11.Size = new Size(174, 25);
            label11.TabIndex = 101;
            label11.Text = " *Email Address";
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.Red;
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 0, 0);
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(746, 753);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(166, 49);
            btnCancel.TabIndex = 114;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btnSub
            // 
            btnSub.BackColor = Color.FromArgb(0, 64, 0);
            btnSub.FlatAppearance.BorderSize = 0;
            btnSub.FlatAppearance.MouseOverBackColor = Color.Green;
            btnSub.FlatStyle = FlatStyle.Flat;
            btnSub.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnSub.ForeColor = Color.White;
            btnSub.Location = new Point(531, 753);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(166, 49);
            btnSub.TabIndex = 115;
            btnSub.Text = "Submit";
            btnSub.UseVisualStyleBackColor = false;
            btnSub.Click += btnSub_Click;
            // 
            // NewUser
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1506, 900);
            Controls.Add(btnSub);
            Controls.Add(btnCancel);
            Controls.Add(textBox6);
            Controls.Add(label13);
            Controls.Add(comboBox4);
            Controls.Add(label12);
            Controls.Add(textBox5);
            Controls.Add(label11);
            Controls.Add(comboBox3);
            Controls.Add(label10);
            Controls.Add(comboBox2);
            Controls.Add(label9);
            Controls.Add(comboBox1);
            Controls.Add(label8);
            Controls.Add(textBox4);
            Controls.Add(label7);
            Controls.Add(label1);
            Controls.Add(textBox3);
            Controls.Add(label6);
            Controls.Add(textBox2);
            Controls.Add(label5);
            Controls.Add(textBox1);
            Controls.Add(cb1);
            Controls.Add(lblTitle);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(lblcancel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "NewUser";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NewUser";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblcancel;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox3;
        private Label label6;
        private TextBox textBox2;
        private Label label5;
        private TextBox textBox1;
        private ComboBox cb1;
        private Label lblTitle;
        private ComboBox comboBox3;
        private Label label10;
        private ComboBox comboBox2;
        private Label label9;
        private ComboBox comboBox1;
        private Label label8;
        private TextBox textBox4;
        private Label label7;
        private TextBox textBox6;
        private Label label13;
        private ComboBox comboBox4;
        private Label label12;
        private TextBox textBox5;
        private Label label11;
        private Button btnCancel;
        private Button btnSub;
    }
}