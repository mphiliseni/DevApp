﻿namespace AppDev
{
    partial class Appointmnt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Appointmnt));
            lblcancel = new Label();
            label3 = new Label();
            label2 = new Label();
            textBox3 = new TextBox();
            label6 = new Label();
            cb1 = new ComboBox();
            lblTitle = new Label();
            textBox6 = new TextBox();
            label13 = new Label();
            textBox5 = new TextBox();
            label11 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label1 = new Label();
            textBox1 = new TextBox();
            label4 = new Label();
            comboBox2 = new ComboBox();
            label5 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            btnSubmit = new Button();
            btnCancel = new Button();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblcancel
            // 
            lblcancel.AutoSize = true;
            lblcancel.BackColor = Color.Red;
            lblcancel.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblcancel.ForeColor = Color.White;
            lblcancel.Location = new Point(1470, 9);
            lblcancel.Name = "lblcancel";
            lblcancel.Size = new Size(24, 25);
            lblcancel.TabIndex = 9;
            lblcancel.Text = "X";
            lblcancel.Click += lblcancel_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.Red;
            label3.Location = new Point(119, 148);
            label3.Name = "label3";
            label3.Size = new Size(172, 28);
            label3.TabIndex = 62;
            label3.Text = "Book Today!";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Segoe UI", 28.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(104, 75);
            label2.Name = "label2";
            label2.Size = new Size(479, 62);
            label2.TabIndex = 63;
            label2.Text = "Schedule Appoitment";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(583, 274);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = " *Surname ";
            textBox3.Size = new Size(394, 30);
            textBox3.TabIndex = 71;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(583, 238);
            label6.Name = "label6";
            label6.Size = new Size(131, 25);
            label6.TabIndex = 70;
            label6.Text = " *Surname ";
            // 
            // cb1
            // 
            cb1.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            cb1.FormattingEnabled = true;
            cb1.Items.AddRange(new object[] { "[Select]", "Mr", "Miss", "Mrs", "Dr", "Prof" });
            cb1.Location = new Point(127, 274);
            cb1.Name = "cb1";
            cb1.Size = new Size(356, 30);
            cb1.TabIndex = 69;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblTitle.Location = new Point(144, 238);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(77, 25);
            lblTitle.TabIndex = 68;
            lblTitle.Text = "*Tittle";
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.Location = new Point(583, 388);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.PlaceholderText = "   *Cellphone No ";
            textBox6.Size = new Size(394, 33);
            textBox6.TabIndex = 85;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(583, 349);
            label13.Name = "label13";
            label13.Size = new Size(187, 25);
            label13.TabIndex = 84;
            label13.Text = "   *Cellphone No ";
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox5.Location = new Point(127, 388);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.PlaceholderText = " *Email Address";
            textBox5.Size = new Size(362, 33);
            textBox5.TabIndex = 83;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(127, 349);
            label11.Name = "label11";
            label11.Size = new Size(174, 25);
            label11.TabIndex = 82;
            label11.Text = " *Email Address";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(121, 513);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(368, 27);
            dateTimePicker1.TabIndex = 100;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(583, 467);
            label1.Name = "label1";
            label1.Size = new Size(112, 25);
            label1.TabIndex = 99;
            label1.Text = "*Initial(s)";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(583, 510);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.PlaceholderText = " *Initial(s) ";
            textBox1.Size = new Size(394, 30);
            textBox1.TabIndex = 98;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(121, 467);
            label4.Name = "label4";
            label4.Size = new Size(159, 25);
            label4.TabIndex = 97;
            label4.Text = " *Choose Date";
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox2.ForeColor = SystemColors.GrayText;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Birth Certificates", "Identity documents", "Marriage certificates", "passports" });
            comboBox2.Location = new Point(119, 618);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(370, 30);
            comboBox2.TabIndex = 107;
            comboBox2.Text = "[Select]";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(117, 577);
            label5.Name = "label5";
            label5.Size = new Size(186, 25);
            label5.TabIndex = 106;
            label5.Text = "*Choose services";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(1067, 444);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(352, 170);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 109;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1067, 251);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(352, 170);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 108;
            pictureBox1.TabStop = false;
            // 
            // btnSubmit
            // 
            btnSubmit.BackColor = Color.FromArgb(0, 64, 0);
            btnSubmit.FlatAppearance.BorderSize = 0;
            btnSubmit.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 192, 0);
            btnSubmit.FlatStyle = FlatStyle.Flat;
            btnSubmit.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnSubmit.ForeColor = Color.White;
            btnSubmit.Location = new Point(595, 728);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(166, 49);
            btnSubmit.TabIndex = 110;
            btnSubmit.Text = "Submit";
            btnSubmit.UseVisualStyleBackColor = false;
            btnSubmit.Click += btnSubmit_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.Red;
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 0, 0);
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(786, 728);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(166, 49);
            btnCancel.TabIndex = 111;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = SystemColors.ControlDarkDark;
            label7.Location = new Point(625, 855);
            label7.Name = "label7";
            label7.Size = new Size(287, 20);
            label7.TabIndex = 112;
            label7.Text = "Secure Portal @ 2024 | We Care";
            // 
            // Appointmnt
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1506, 900);
            Controls.Add(label7);
            Controls.Add(btnCancel);
            Controls.Add(btnSubmit);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(comboBox2);
            Controls.Add(label5);
            Controls.Add(dateTimePicker1);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(textBox6);
            Controls.Add(label13);
            Controls.Add(textBox5);
            Controls.Add(label11);
            Controls.Add(textBox3);
            Controls.Add(label6);
            Controls.Add(cb1);
            Controls.Add(lblTitle);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(lblcancel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Appointmnt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Appointmnt";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblcancel;
        private Label label3;
        private Label label2;
        private TextBox textBox3;
        private Label label6;
        private ComboBox cb1;
        private Label lblTitle;
        private TextBox textBox6;
        private Label label13;
        private TextBox textBox5;
        private Label label11;
        private DateTimePicker dateTimePicker1;
        private Label label1;
        private TextBox textBox1;
        private Label label4;
        private ComboBox comboBox2;
        private Label label5;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Button btnSubmit;
        private Button btnCancel;
        private Label label7;
    }
}