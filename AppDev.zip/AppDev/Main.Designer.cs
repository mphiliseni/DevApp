﻿namespace AppDev
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            pictureBox = new PictureBox();
            lblcancel = new Label();
            tabControl = new TabControl();
            tabPageHome = new TabPage();
            label7 = new Label();
            linkLabel1 = new LinkLabel();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            tabPageAbout = new TabPage();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            tabPageCivilServices = new TabPage();
            label6 = new Label();
            btnApply = new Button();
            button5 = new Button();
            button3 = new Button();
            button4 = new Button();
            label8 = new Label();
            label9 = new Label();
            label11 = new Label();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            label10 = new Label();
            pictureBox6 = new PictureBox();
            label5 = new Label();
            label4 = new Label();
            tabPageSmartCards = new TabPage();
            lblstartNow = new Label();
            label20 = new Label();
            pictureBox8 = new PictureBox();
            label19 = new Label();
            pictureBox7 = new PictureBox();
            label18 = new Label();
            tabPageContact = new TabPage();
            label14 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox9 = new PictureBox();
            label13 = new Label();
            label12 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            tabControl.SuspendLayout();
            tabPageHome.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabPageAbout.SuspendLayout();
            tabPageCivilServices.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            tabPageSmartCards.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            tabPageContact.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            SuspendLayout();
            // 
            // pictureBox
            // 
            pictureBox.Image = (Image)resources.GetObject("pictureBox.Image");
            pictureBox.Location = new Point(1, -1);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(1505, 155);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.TabIndex = 0;
            pictureBox.TabStop = false;
            // 
            // lblcancel
            // 
            lblcancel.AutoSize = true;
            lblcancel.BackColor = Color.Red;
            lblcancel.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblcancel.ForeColor = Color.White;
            lblcancel.Location = new Point(1470, 9);
            lblcancel.Name = "lblcancel";
            lblcancel.Size = new Size(24, 25);
            lblcancel.TabIndex = 68;
            lblcancel.Text = "X";
            lblcancel.Click += lblcancel_Click;
            // 
            // tabControl
            // 
            tabControl.Controls.Add(tabPageHome);
            tabControl.Controls.Add(tabPageAbout);
            tabControl.Controls.Add(tabPageCivilServices);
            tabControl.Controls.Add(tabPageSmartCards);
            tabControl.Controls.Add(tabPageContact);
            tabControl.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            tabControl.Location = new Point(1, 160);
            tabControl.Name = "tabControl";
            tabControl.SelectedIndex = 0;
            tabControl.Size = new Size(1505, 739);
            tabControl.TabIndex = 69;
            // 
            // tabPageHome
            // 
            tabPageHome.Controls.Add(label7);
            tabPageHome.Controls.Add(linkLabel1);
            tabPageHome.Controls.Add(label3);
            tabPageHome.Controls.Add(pictureBox1);
            tabPageHome.Controls.Add(label1);
            tabPageHome.Controls.Add(label2);
            tabPageHome.Location = new Point(4, 32);
            tabPageHome.Name = "tabPageHome";
            tabPageHome.Padding = new Padding(3);
            tabPageHome.Size = new Size(1497, 703);
            tabPageHome.TabIndex = 0;
            tabPageHome.Text = "Home";
            tabPageHome.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = SystemColors.ControlDarkDark;
            label7.Location = new Point(609, 665);
            label7.Name = "label7";
            label7.Size = new Size(287, 20);
            label7.TabIndex = 113;
            label7.Text = "Secure Portal @ 2024 | We Care";
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            linkLabel1.ForeColor = Color.Red;
            linkLabel1.LinkBehavior = LinkBehavior.HoverUnderline;
            linkLabel1.LinkColor = Color.Red;
            linkLabel1.Location = new Point(483, 466);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(127, 20);
            linkLabel1.TabIndex = 68;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Read More...";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.Black;
            label3.ImageAlign = ContentAlignment.MiddleLeft;
            label3.Location = new Point(483, 230);
            label3.Name = "label3";
            label3.Size = new Size(908, 216);
            label3.TabIndex = 67;
            label3.Text = resources.GetString("label3.Text");
            label3.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(216, 214);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(251, 305);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 66;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.Green;
            label1.Location = new Point(216, 139);
            label1.Name = "label1";
            label1.Size = new Size(470, 31);
            label1.TabIndex = 65;
            label1.Text = "Easy to use, convenient, and just a click away";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(216, 84);
            label2.Name = "label2";
            label2.Size = new Size(360, 38);
            label2.TabIndex = 64;
            label2.Text = "Welcome to Secured Portal!";
            // 
            // tabPageAbout
            // 
            tabPageAbout.Controls.Add(label17);
            tabPageAbout.Controls.Add(label16);
            tabPageAbout.Controls.Add(label15);
            tabPageAbout.Location = new Point(4, 32);
            tabPageAbout.Name = "tabPageAbout";
            tabPageAbout.Padding = new Padding(3);
            tabPageAbout.Size = new Size(1497, 703);
            tabPageAbout.TabIndex = 1;
            tabPageAbout.Text = "About";
            tabPageAbout.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = SystemColors.ControlDarkDark;
            label17.Location = new Point(657, 670);
            label17.Name = "label17";
            label17.Size = new Size(287, 20);
            label17.TabIndex = 124;
            label17.Text = "Secure Portal @ 2024 | We Care";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label16.ForeColor = Color.Black;
            label16.ImageAlign = ContentAlignment.MiddleLeft;
            label16.Location = new Point(40, 154);
            label16.Name = "label16";
            label16.Size = new Size(1359, 360);
            label16.TabIndex = 68;
            label16.Text = resources.GetString("label16.Text");
            label16.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.FlatStyle = FlatStyle.Flat;
            label15.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label15.Location = new Point(40, 75);
            label15.Name = "label15";
            label15.Size = new Size(128, 38);
            label15.TabIndex = 67;
            label15.Text = "About us";
            // 
            // tabPageCivilServices
            // 
            tabPageCivilServices.Controls.Add(label6);
            tabPageCivilServices.Controls.Add(btnApply);
            tabPageCivilServices.Controls.Add(button5);
            tabPageCivilServices.Controls.Add(button3);
            tabPageCivilServices.Controls.Add(button4);
            tabPageCivilServices.Controls.Add(label8);
            tabPageCivilServices.Controls.Add(label9);
            tabPageCivilServices.Controls.Add(label11);
            tabPageCivilServices.Controls.Add(pictureBox5);
            tabPageCivilServices.Controls.Add(pictureBox4);
            tabPageCivilServices.Controls.Add(pictureBox3);
            tabPageCivilServices.Controls.Add(label10);
            tabPageCivilServices.Controls.Add(pictureBox6);
            tabPageCivilServices.Controls.Add(label5);
            tabPageCivilServices.Controls.Add(label4);
            tabPageCivilServices.Location = new Point(4, 32);
            tabPageCivilServices.Name = "tabPageCivilServices";
            tabPageCivilServices.Size = new Size(1497, 703);
            tabPageCivilServices.TabIndex = 2;
            tabPageCivilServices.Text = "Civil Services";
            tabPageCivilServices.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.ControlDarkDark;
            label6.Location = new Point(52, 664);
            label6.Name = "label6";
            label6.Size = new Size(287, 20);
            label6.TabIndex = 123;
            label6.Text = "Secure Portal @ 2024 | We Care";
            // 
            // btnApply
            // 
            btnApply.BackColor = Color.Green;
            btnApply.FlatAppearance.BorderSize = 0;
            btnApply.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 192, 0);
            btnApply.FlatStyle = FlatStyle.Flat;
            btnApply.ForeColor = Color.White;
            btnApply.Location = new Point(69, 444);
            btnApply.Name = "btnApply";
            btnApply.Size = new Size(259, 56);
            btnApply.TabIndex = 122;
            btnApply.Text = "Apply Now";
            btnApply.UseVisualStyleBackColor = false;
            btnApply.Click += button2_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.Green;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 192, 0);
            button5.FlatStyle = FlatStyle.Flat;
            button5.ForeColor = Color.White;
            button5.Location = new Point(419, 444);
            button5.Name = "button5";
            button5.Size = new Size(259, 56);
            button5.TabIndex = 121;
            button5.Text = "Apply Now";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.Green;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 192, 0);
            button3.FlatStyle = FlatStyle.Flat;
            button3.ForeColor = Color.White;
            button3.Location = new Point(796, 444);
            button3.Name = "button3";
            button3.Size = new Size(259, 56);
            button3.TabIndex = 120;
            button3.Text = "Apply Now";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.Green;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 192, 0);
            button4.FlatStyle = FlatStyle.Flat;
            button4.ForeColor = Color.White;
            button4.Location = new Point(1165, 444);
            button4.Name = "button4";
            button4.Size = new Size(259, 56);
            button4.TabIndex = 119;
            button4.Text = "Apply Now";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.Window;
            label8.FlatStyle = FlatStyle.Flat;
            label8.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(1188, 407);
            label8.Name = "label8";
            label8.Size = new Size(196, 20);
            label8.TabIndex = 118;
            label8.Text = "Marriage Certificate";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.Window;
            label9.FlatStyle = FlatStyle.Flat;
            label9.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.Black;
            label9.Location = new Point(814, 408);
            label9.Name = "label9";
            label9.Size = new Size(212, 20);
            label9.TabIndex = 116;
            label9.Text = "Birt Cert Registration";
            label9.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = SystemColors.Window;
            label11.FlatStyle = FlatStyle.Flat;
            label11.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.Black;
            label11.Location = new Point(461, 407);
            label11.Name = "label11";
            label11.Size = new Size(183, 20);
            label11.TabIndex = 114;
            label11.Text = "Passport Issuance";
            label11.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(1148, 204);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(277, 195);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 111;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(781, 204);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(284, 200);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 108;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(402, 204);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(301, 195);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 105;
            pictureBox3.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = SystemColors.Window;
            label10.FlatStyle = FlatStyle.Flat;
            label10.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.Black;
            label10.Location = new Point(69, 406);
            label10.Name = "label10";
            label10.Size = new Size(257, 20);
            label10.TabIndex = 103;
            label10.Text = "Citizenship ID Application";
            label10.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(52, 210);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(292, 189);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 102;
            pictureBox6.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(52, 48);
            label5.Name = "label5";
            label5.Size = new Size(172, 38);
            label5.TabIndex = 66;
            label5.Text = "Our Services";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.FlatStyle = FlatStyle.Flat;
            label4.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(0, 192, 0);
            label4.Location = new Point(52, 120);
            label4.Name = "label4";
            label4.Size = new Size(764, 46);
            label4.TabIndex = 65;
            label4.Text = "These are achieved by issuing South African nationals and residents with documents pertaining to: \r\nBirths, Marriages and Deaths, Identity Documents and Identification etc.";
            // 
            // tabPageSmartCards
            // 
            tabPageSmartCards.Controls.Add(lblstartNow);
            tabPageSmartCards.Controls.Add(label20);
            tabPageSmartCards.Controls.Add(pictureBox8);
            tabPageSmartCards.Controls.Add(label19);
            tabPageSmartCards.Controls.Add(pictureBox7);
            tabPageSmartCards.Controls.Add(label18);
            tabPageSmartCards.Location = new Point(4, 32);
            tabPageSmartCards.Name = "tabPageSmartCards";
            tabPageSmartCards.Size = new Size(1497, 703);
            tabPageSmartCards.TabIndex = 3;
            tabPageSmartCards.Text = "Smart Cards";
            tabPageSmartCards.UseVisualStyleBackColor = true;
            // 
            // lblstartNow
            // 
            lblstartNow.AutoSize = true;
            lblstartNow.Font = new Font("Verdana", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblstartNow.ForeColor = Color.Red;
            lblstartNow.Location = new Point(28, 525);
            lblstartNow.Name = "lblstartNow";
            lblstartNow.Size = new Size(132, 22);
            lblstartNow.TabIndex = 127;
            lblstartNow.Text = "Start Now...";
            lblstartNow.Click += lblstartNow_Click;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.BackColor = Color.Transparent;
            label20.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label20.ForeColor = SystemColors.ControlDarkDark;
            label20.Location = new Point(28, 661);
            label20.Name = "label20";
            label20.Size = new Size(287, 20);
            label20.TabIndex = 124;
            label20.Text = "Secure Portal @ 2024 | We Care";
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(853, 44);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(580, 637);
            pictureBox8.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox8.TabIndex = 105;
            pictureBox8.TabStop = false;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.Transparent;
            label19.FlatStyle = FlatStyle.Flat;
            label19.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = SystemColors.ControlDarkDark;
            label19.Location = new Point(28, 300);
            label19.Name = "label19";
            label19.Size = new Size(810, 198);
            label19.TabIndex = 104;
            label19.Text = resources.GetString("label19.Text");
            label19.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(28, 110);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(342, 108);
            pictureBox7.TabIndex = 92;
            pictureBox7.TabStop = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.FlatStyle = FlatStyle.Flat;
            label18.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label18.Location = new Point(28, 47);
            label18.Name = "label18";
            label18.Size = new Size(381, 38);
            label18.TabIndex = 68;
            label18.Text = "Know your new smart ID card";
            // 
            // tabPageContact
            // 
            tabPageContact.Controls.Add(label14);
            tabPageContact.Controls.Add(pictureBox2);
            tabPageContact.Controls.Add(pictureBox9);
            tabPageContact.Controls.Add(label13);
            tabPageContact.Controls.Add(label12);
            tabPageContact.Location = new Point(4, 32);
            tabPageContact.Name = "tabPageContact";
            tabPageContact.Size = new Size(1497, 703);
            tabPageContact.TabIndex = 4;
            tabPageContact.Text = "Contact us";
            tabPageContact.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label14.ForeColor = SystemColors.ControlDarkDark;
            label14.Location = new Point(623, 662);
            label14.Name = "label14";
            label14.Size = new Size(287, 20);
            label14.TabIndex = 124;
            label14.Text = "Secure Portal @ 2024 | We Care";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(550, 169);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(405, 231);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 108;
            pictureBox2.TabStop = false;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(961, 169);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(405, 231);
            pictureBox9.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox9.TabIndex = 107;
            pictureBox9.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.FlatStyle = FlatStyle.Flat;
            label13.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = SystemColors.ControlDarkDark;
            label13.Location = new Point(140, 169);
            label13.Name = "label13";
            label13.Size = new Size(293, 220);
            label13.TabIndex = 105;
            label13.Text = "Home Affairs Headquarters\r\nContact Centre\r\n\r\nhacc@dha.gov.za\r\nPretoria, Gauteng, South Africa\r\nPhone: 0800 601 190\r\nHome Affairs Headquarters\r\n\r\nPretoria, Gauteng, South Africa\r\nPhone: 012 406 2500\r\n";
            label13.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.FlatStyle = FlatStyle.Flat;
            label12.Font = new Font("Segoe UI", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(140, 77);
            label12.Name = "label12";
            label12.Size = new Size(147, 38);
            label12.TabIndex = 65;
            label12.Text = "Contact us";
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1506, 900);
            Controls.Add(tabControl);
            Controls.Add(lblcancel);
            Controls.Add(pictureBox);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Main";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Main";
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            tabControl.ResumeLayout(false);
            tabPageHome.ResumeLayout(false);
            tabPageHome.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabPageAbout.ResumeLayout(false);
            tabPageAbout.PerformLayout();
            tabPageCivilServices.ResumeLayout(false);
            tabPageCivilServices.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            tabPageSmartCards.ResumeLayout(false);
            tabPageSmartCards.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            tabPageContact.ResumeLayout(false);
            tabPageContact.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox;
        private Label lblcancel;
        private TabControl tabControl;
        private TabPage tabPageHome;
        private TabPage tabPageAbout;
        private TabPage tabPageCivilServices;
        private TabPage tabPageSmartCards;
        private TabPage tabPageContact;
        private Label label1;
        private Label label2;
        private LinkLabel linkLabel1;
        private Label label3;
        private PictureBox pictureBox1;
        private Label label7;
        private Label label5;
        private Label label4;
        private Button button4;
        private Label label8;
        private Label label9;
        private Label label11;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private Label label10;
        private PictureBox pictureBox6;
        private Button btnApply;
        private Button button3;
        private Label label6;
        private PictureBox pictureBox9;
        private Label label13;
        private Label label12;
        private PictureBox pictureBox2;
        private Label label14;
        private Button button5;
        private Label label15;
        private Label label17;
        private Label label16;
        private Label label18;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private Label label19;
        private Label label20;
        private Label lblstartNow;
    }
}