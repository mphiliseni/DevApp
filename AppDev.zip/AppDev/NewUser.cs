﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev
{
    public partial class NewUser : Form
    {
        public NewUser()
        {
            InitializeComponent();
        }

        private void lblcancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
           
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            UStatus usts = new UStatus();
            usts.Show();
            this.Hide();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            flogin lgn = new flogin();
            lgn.Show();
            this.Hide();
        }
    }
}
