﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev
{
    public partial class UStatus : Form
    {
        public UStatus()
        {
            InitializeComponent();
        }

        private void btnProceedData_Click(object sender, EventArgs e)
        {
            ViewData vd = new ViewData();
            vd.Show();
            this.Hide();
        }
    }
}
