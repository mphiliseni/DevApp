﻿namespace AppDev
{
    partial class UStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UStatus));
            btnProceedData = new Button();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnProceedData
            // 
            btnProceedData.BackColor = Color.FromArgb(0, 64, 0);
            btnProceedData.FlatAppearance.BorderSize = 0;
            btnProceedData.FlatAppearance.MouseOverBackColor = Color.Green;
            btnProceedData.FlatStyle = FlatStyle.Flat;
            btnProceedData.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnProceedData.ForeColor = Color.White;
            btnProceedData.Location = new Point(466, 513);
            btnProceedData.Name = "btnProceedData";
            btnProceedData.Size = new Size(588, 43);
            btnProceedData.TabIndex = 12;
            btnProceedData.Text = "View Data ";
            btnProceedData.UseVisualStyleBackColor = false;
            btnProceedData.Click += btnProceedData_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Segoe UI", 36F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(435, 354);
            label2.Name = "label2";
            label2.Size = new Size(653, 81);
            label2.TabIndex = 11;
            label2.Text = "Submited Successfully! ";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(679, 151);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(154, 156);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ControlDarkDark;
            label1.Location = new Point(623, 729);
            label1.Name = "label1";
            label1.Size = new Size(287, 20);
            label1.TabIndex = 114;
            label1.Text = "Secure Portal @ 2024 | We Care";
            // 
            // UStatus
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1506, 900);
            Controls.Add(label1);
            Controls.Add(btnProceedData);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "UStatus";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "UStatus";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnProceedData;
        private Label label2;
        private PictureBox pictureBox1;
        private Label label1;
    }
}