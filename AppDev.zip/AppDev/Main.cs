﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppDev
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void lblcancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            NewUser nw = new NewUser();
            nw.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            NewUser nw = new NewUser();
            nw.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            NewUser nw = new NewUser();
            nw.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            NewUser nw = new NewUser();
            nw.Show();
            this.Hide();
        }

        private void lblstartNow_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            
        }

        private void rbnstartnow_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void lblstartNow_Click(object sender, EventArgs e)
        {
            NewUser nw = new NewUser();
            nw.Show();
            this.Hide();
        }
    }
}
