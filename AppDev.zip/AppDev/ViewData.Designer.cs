﻿namespace AppDev
{
    partial class ViewData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblcancel = new Label();
            label2 = new Label();
            comboBox1 = new ComboBox();
            label5 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label1 = new Label();
            textBox1 = new TextBox();
            label3 = new Label();
            textBox6 = new TextBox();
            label13 = new Label();
            textBox5 = new TextBox();
            label11 = new Label();
            textBox3 = new TextBox();
            label6 = new Label();
            cb1 = new ComboBox();
            lblTitle = new Label();
            btnLogout = new Button();
            btnLearnMore = new Button();
            SuspendLayout();
            // 
            // lblcancel
            // 
            lblcancel.AutoSize = true;
            lblcancel.BackColor = Color.Red;
            lblcancel.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblcancel.ForeColor = Color.White;
            lblcancel.Location = new Point(1470, 9);
            lblcancel.Name = "lblcancel";
            lblcancel.Size = new Size(24, 25);
            lblcancel.TabIndex = 11;
            lblcancel.Text = "X";
            lblcancel.Click += lblcancel_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Segoe UI", 28.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(236, 65);
            label2.Name = "label2";
            label2.Size = new Size(485, 62);
            label2.TabIndex = 65;
            label2.Text = "Confirm Your booking";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "[Select]", "Birth Certificates", "Identity documents", "Marriage certificates", "passports" });
            comboBox1.Location = new Point(247, 603);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(348, 30);
            comboBox1.TabIndex = 132;
            comboBox1.Text = "Marriage certificates";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(258, 567);
            label5.Name = "label5";
            label5.Size = new Size(186, 25);
            label5.TabIndex = 131;
            label5.Text = "*Choose services";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(247, 476);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(348, 27);
            dateTimePicker1.TabIndex = 130;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(768, 430);
            label1.Name = "label1";
            label1.Size = new Size(112, 25);
            label1.TabIndex = 129;
            label1.Text = "*Initial(s)";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(768, 476);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(349, 36);
            textBox1.TabIndex = 128;
            textBox1.Text = "M.M";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(247, 430);
            label3.Name = "label3";
            label3.Size = new Size(159, 25);
            label3.TabIndex = 127;
            label3.Text = " *Choose Date";
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.Location = new Point(768, 335);
            textBox6.Multiline = true;
            textBox6.Name = "textBox6";
            textBox6.PlaceholderText = "  ";
            textBox6.Size = new Size(349, 33);
            textBox6.TabIndex = 126;
            textBox6.Text = "076 221 1010";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(752, 296);
            label13.Name = "label13";
            label13.Size = new Size(187, 25);
            label13.TabIndex = 125;
            label13.Text = "   *Cellphone No ";
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox5.Location = new Point(247, 335);
            textBox5.Multiline = true;
            textBox5.Name = "textBox5";
            textBox5.PlaceholderText = " *Email Address";
            textBox5.Size = new Size(348, 33);
            textBox5.TabIndex = 124;
            textBox5.Text = "mhlongo226@gmail.com";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(247, 296);
            label11.Name = "label11";
            label11.Size = new Size(174, 25);
            label11.TabIndex = 123;
            label11.Text = " *Email Address";
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(768, 215);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.PlaceholderText = " *Surname ";
            textBox3.Size = new Size(349, 37);
            textBox3.TabIndex = 122;
            textBox3.Text = "Mhlongo";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(768, 179);
            label6.Name = "label6";
            label6.Size = new Size(131, 25);
            label6.TabIndex = 121;
            label6.Text = " *Surname ";
            // 
            // cb1
            // 
            cb1.Font = new Font("Verdana", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            cb1.FormattingEnabled = true;
            cb1.Items.AddRange(new object[] { "[Select]", "Mr", "Miss", "Mrs", "Dr", "Prof" });
            cb1.Location = new Point(247, 215);
            cb1.Name = "cb1";
            cb1.Size = new Size(348, 30);
            cb1.TabIndex = 120;
            cb1.Text = "Mr";
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblTitle.Location = new Point(258, 179);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(77, 25);
            lblTitle.TabIndex = 119;
            lblTitle.Text = "*Tittle";
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.Red;
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.FlatAppearance.MouseOverBackColor = Color.FromArgb(192, 0, 0);
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnLogout.ForeColor = Color.White;
            btnLogout.Location = new Point(793, 713);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(166, 49);
            btnLogout.TabIndex = 134;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += btnLogout_Click;
            // 
            // btnLearnMore
            // 
            btnLearnMore.BackColor = Color.FromArgb(0, 64, 0);
            btnLearnMore.FlatAppearance.BorderSize = 0;
            btnLearnMore.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 192, 0);
            btnLearnMore.FlatStyle = FlatStyle.Flat;
            btnLearnMore.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnLearnMore.ForeColor = Color.White;
            btnLearnMore.Location = new Point(602, 713);
            btnLearnMore.Name = "btnLearnMore";
            btnLearnMore.Size = new Size(166, 49);
            btnLearnMore.TabIndex = 133;
            btnLearnMore.Text = "Learn More";
            btnLearnMore.UseVisualStyleBackColor = false;
            btnLearnMore.Click += btnLearnMore_Click;
            // 
            // ViewData
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1506, 900);
            Controls.Add(btnLogout);
            Controls.Add(btnLearnMore);
            Controls.Add(comboBox1);
            Controls.Add(label5);
            Controls.Add(dateTimePicker1);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(textBox6);
            Controls.Add(label13);
            Controls.Add(textBox5);
            Controls.Add(label11);
            Controls.Add(textBox3);
            Controls.Add(label6);
            Controls.Add(cb1);
            Controls.Add(lblTitle);
            Controls.Add(label2);
            Controls.Add(lblcancel);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ViewData";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ViewData";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblcancel;
        private Label label2;
        private ComboBox comboBox1;
        private Label label5;
        private DateTimePicker dateTimePicker1;
        private Label label1;
        private TextBox textBox1;
        private Label label3;
        private TextBox textBox6;
        private Label label13;
        private TextBox textBox5;
        private Label label11;
        private TextBox textBox3;
        private Label label6;
        private ComboBox cb1;
        private Label lblTitle;
        private Button btnLogout;
        private Button btnLearnMore;
    }
}